
function VideoDetailStore(){

    riot.observable(this);
    var self = this;
    self.doctors = [];
    self.vsrc = [];
    self.vcontent = [];<!--视频链接,视频简介-->

    self.on("getVideoDetail",function(userid){
        $.ajax({
            url: dfs.apiPostUrl + "/dfs_load_posts_by_user?userid=" + userid,
            async: true,
            type: "get",
            dataType: 'json',
            contentType:"application/json;charset=utf-8",
            success: function(data) {
                self.doctors = data;
                console.log(data);
                self.trigger("videoDetailChanged",self.doctors);
            }
        });

    });

}
