function CollectStore(){
    riot.observable(this);
    var self = this;
//收藏
    self.on("getCollectList",function(collectMsg){
        var collect = {
            "userid" : collectMsg.userid
        };
        $.post("http://api.daifushuo.com:80/api/obookmarks/dfs_load_bookmarks_by_user_id?access_token="+collectMsg.accessToken,collect,function(data){
            $(data).each(function(){
                if(this.media == "4"){
                    this.media = "专题号";
                }else{
                    this.media = "大夫号";
                }
            });
            self.trigger("collectListChanged",data);
        });

    });
    //历史播放
    self.on("getHistoryList",function(historyMsg){
        $.get("http://api.daifushuo.com:80/api/viewlog/dfs_find_viewlog_by_user_id?userid="+historyMsg.userid+"&access_token="+historyMsg.accessToken,function(data){
            $(data).each(function(){
                if(this.media == "4"){
                    this.media = "专题号";
                }else{
                    this.media = "大夫号";
                }
            });
            self.trigger("historyListChanged",data);
        })
    });
}