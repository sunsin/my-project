
function VideoListStore(){
    riot.observable(this);
    var self = this;
    self.ilist = [];

//轮播carousel
    self.on("getCarouselList",function(){
        $.ajax({
            url: "http://test.daifushuo.com:80/api/slide-img",
            async: true,
            type: "get",
            dataType: 'json',
            contentType:"application/json;charset=utf-8",
            success: function(data) {
                self.carousel = data;
                self.trigger("carouselListChanged",self.carousel);
            }
        });

    });
//热门视频
    self.on("getHotVideoList",function(page){
        $.ajax({
            url: dfs.apiPostUrl+"/dfs_load_posts_hot?/size=10&page=" + page,
            async: true,
            type: "get",
            dataType: 'json',
            contentType:"application/json;charset=utf-8",
            success: function(data) {
                self.ilist = data;
                self.trigger("videoHotListChanged",self.ilist);
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {

            }
        });

    });
//时间倒序(最新)
    self.on("getNewVideoList",function(page){
        $.ajax({
            url: dfs.apiPostUrl+"/dfs_load_posts?/size=10&page=" + page,
            async: true,
            type: "get",
            dataType: 'json',
            contentType:"application/json;charset=utf-8",
            success: function(data) {
                self.ilist = data;
                self.trigger("videoNewListChanged",self.ilist);
            }
        });

    });
//关注
    self.on("getFocusVideoList",function(page){

        $.ajax({
            url: dfs.apiPostUrl+"/dfs_load_posts_to_user_page?userid="+page.userid+"&access_token="+page.access_token +"&page="+page.page,
            async: true,
            type: "get",
            dataType: 'json',
            contentType:"application/json;charset=utf-8",
            success: function(data) {
                self.ilist = data;
                self.trigger("videoFocusListChanged",self.ilist);
            }
        });

    });
//导航其他topic
    self.on("getOtherVideoList",function(topicQuery){
        $.post("http://api.daifushuo.com:80/api/search/dfs_search_topics",topicQuery,function(data){
            self.trigger("videoOtherListChanged",data);
        });

    });
//按科室搜索
    self.on("getRoomVideoList",function(query){
        $.post("http://api.daifushuo.com:80/api/search/dfs_search_room",query,function(data){
            self.trigger("videoListChanged",data);
        });

    });

//导航栏
    self.on("getTopicList",function(){
        $.get("http://api.daifushuo.com:80/api/tools/dfs_topic_list",function(data){
            self.trigger("topicListChanged",data);
        });

    });

}
